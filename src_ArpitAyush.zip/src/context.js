import React, { Component } from "react";

const Context = React.createContext();

export class Provider extends Component {
  handler = (action, newObject) => {
    switch (action) {
      case "ADD_PROJECT":
        this.setState({
          projects: [newObject, ...this.state.projects],
        });
        break;
      case "ADD_BLOG":
        this.setState({
          blogs: [newObject, ...this.state.blogs],
        });
        break;
      case "ADD_RECOMMENDATION":
        this.setState({
          recommendations: [newObject, ...this.state.recommendations],
        });
        break;
      default:
        break;
    }
  };

  state = {
    handler: this.handler,

    recommendations: [
      {
        id: 1,
        name: "Colleague 1",
        company: "EMConstants",
        designation: "CEO",
        message: "He gets things done quickly and is a very creative and hardworking person.",
      },
      {
        id: 2,
        name: "Colleague 2",
        company: "EMConstants",
        designation: "Manager",
        message: "He is an excellent developer",
      },
      {
        id: 3,
        name: "Colleague 3",
        company: "EMConstants",
        designation: "Director",
        message: "He is a lazy person",
      },
      {
        id: 4,
        name: "Colleague 4",
        company: "EMConstants",
        designation: "Team Lead",
        message: "He is a good engineer",
      },
    ],

    skills: [
      {
        id: 1,
        name: "HTML5",
        imageUrl: require("./assets/html5.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 2,
        name: "CSS3",
        imageUrl: require("./assets/css3.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 3,
        name: "Javascript",
        imageUrl: require("./assets/javascript.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 4,
        name: "Bootstrap 4",
        imageUrl: require("./assets/bootstrap4.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 5,
        name: "React",
        imageUrl: require("./assets/react.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 6,
        name: "MySQL",
        imageUrl: require("./assets/mysql.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 7,
        name: "Python",
        imageUrl: require("./assets/python.png"),
        starsTotal: 5,
        starsActive: 3,
      },
      {
        id: 8,
        name: "Flask",
        imageUrl: require("./assets/flask.png"),
        starsTotal: 5,
        starsActive: 2,
      },
    ],

    projects: [
      {
        id: 1,
        title: "Project 1",
        imageUrl: require("./assets/free-stock-image-1.jpg"),
        excerpt: "This is my project about...",
        body: "Body-1",
      },
      {
        id: 2,
        title: "Project 2",
        imageUrl: require("./assets/free-stock-image-2.jpg"),
        excerpt: "This is my project about...",
        body: "Body-2",
      },
      {
        id: 3,
        title: "Project 3",
        imageUrl: require("./assets/free-stock-image-3.jpg"),
        excerpt: "This is my project about...",
        body: "Body-3",
      },
      {
        id: 4,
        title: "Project 4",
        imageUrl: require("./assets/free-stock-image-3.jpg"),
        excerpt: "This is my project about...",
        body: "Body-4",
      },
    ],

    blogs: [
      {
        id: 1,
        title: "Blog-1",
        excerpt: "No need to read it",
        imageUrl: require("./assets/free-stock-image-2.jpg"),
        body: "body-1",
      },
      {
        id: 2,
        title: "Blog-2",
        excerpt: "You can read it",
        imageUrl: require("./assets/free-stock-image-3.jpg"),
        body: "body-2",
      },
      {
        id: 3,
        title: "Blog-3",
        excerpt: "You have to read it",
        imageUrl: require("./assets/free-stock-image-1.jpg"),
        body: "body-3",
      },
      {
        id: 4,
        title: "Blog-4",
        excerpt: "You have to read it",
        imageUrl: require("./assets/free-stock-image-1.jpg"),
        body: "body-4",
      },
    ],
  };

  render() {
    return <Context.Provider value={this.state}>{this.props.children}</Context.Provider>;
  }
}

export const Consumer = Context.Consumer;
