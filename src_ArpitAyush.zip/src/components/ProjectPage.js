import React from "react";
import ReactMarkdown from "react-markdown";
import { useParams } from "react-router-dom";
import { Consumer } from "../context";

function ProjectPage() {
  const { id } = useParams();
  return (
    <Consumer>
      {(value) => {
        const { projects } = value;
        const project = projects.filter((project) => project.id === Number(id))[0];
        const { imageUrl, title, body } = project;
        return (
          <div className="container py-5 my-5 markdown">
            <div className="justify-content-center">
              <img src={imageUrl} alt={title} className="w-100" />
            </div>
            <h1 className="font-weight-light text-center my-5">{title}</h1>
            <ReactMarkdown children={body} />
          </div>
        );
      }}
    </Consumer>
  );
}

export default ProjectPage;
