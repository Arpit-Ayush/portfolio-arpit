import React from "react";

function About() {
  return (
    <div className="bg-light">
      <div className="container text-center my-5 py-5">
        <h1 className="font-weight-light">
          <span className="text-info">About</span> me
        </h1>
        <div className="lead">I am trying to improve as a programmer.</div>
        <div className="row text-justify">
          <div className="col-12 col-md-6 pt-5 px-5">
            <h6 className="text-center">What I can do?</h6>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
            atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
          </div>
          <div className="col-12 col-md-6 pt-5 px-5">
            <h6 className="text-center">What am I doing currently?</h6>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
            atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
          </div>
        </div>
        <div className="row text-justify">
          <div className="col-12 col-md-6 pt-5 px-5">
            <h6 className="text-center">What do I believe in?</h6>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
            atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
          </div>
          <div className="col-12 col-md-6 pt-5 px-5">
            <h6 className="text-center">How can I help you?</h6>
            At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti
            atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
