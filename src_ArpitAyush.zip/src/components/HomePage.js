import React from "react";
import About from "./About";
import BlogSection from "./BlogSection";
import ProjectSection from "./ProjectSection";
import RecommendationSection from "./RecommendationSection";
import SkillsSection from "./SkillsSection";
import Title from "./Title";

function HomePage() {
  return (
    <div>
      <Title name="Arpit Ayush" leadText="I am a Full Stack Developer." />
      <RecommendationSection />
      <SkillsSection />
      <ProjectSection />
      <About />
      <BlogSection />
    </div>
  );
}

export default HomePage;
